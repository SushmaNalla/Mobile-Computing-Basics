
import UIKit

var a = 10;
var b = 20;
var sum = 0;
sum = a+b;
print(sum)
// String interpolation
print("The Sum is : \(sum)")
//terminator
print("The sum is: ", terminator:"-")
print(sum)
//seperator
print(1,2,3)
print(1,2,3, separator:" , ")
// variable can be changed
var a1 = 20;
var b1 = 20;
a1 = a1-b1;
print(a1, b1)

