import UIKit

var a = 10
var b = 20
var sum = 0;
sum = a+b;
print(sum)

var c = 20.5
var d = 10.5;
var product = 0.0;
product = c*d;
print(product)

var e = 20;
var f = 15;
var div = 0;
div = e/f;
print(div)

